const services = [
  {
    name: "تجديد الهوية الوطنية",
    provider: "الأحوال المدنية",
    price: "100 ريال"
  },
  {
    name: "نقل ملكية مركبة",
    provider: "المرور",
    price: "150 ريال"
  },
  {
    name: "إصدار سجل تجاري",
    provider: "وزارة التجارة",
    price: "200 ريال"
  }
];

const servicesList = document.getElementById("services-list");
const searchInput = document.getElementById("search");

function displayServices(filteredServices) {
  servicesList.innerHTML = "";
  filteredServices.forEach(service => {
    const card = document.createElement("div");
    card.className = "service-card";
    card.innerHTML = `
      <h2>${service.name}</h2>
      <p><strong>الجهة:</strong> ${service.provider}</p>
      <p><strong>السعر:</strong> ${service.price}</p>
    `;
    servicesList.appendChild(card);
  });
}

searchInput.addEventListener("input", () => {
  const keyword = searchInput.value.toLowerCase();
  const filtered = services.filter(service =>
    service.name.toLowerCase().includes(keyword)
  );
  displayServices(filtered);
});

// عرض كل الخدمات عند التحميل
displayServices(services);
